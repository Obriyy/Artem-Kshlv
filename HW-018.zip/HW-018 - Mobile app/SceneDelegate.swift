//
//  SceneDelegate.swift
//  HW-018 - Mobile app
//
//  Created by PRPL on 03.06.2020.
//  Copyright © 2020 kosheliev. All rights reserved.
//

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

   var window: UIWindow?
   
}

