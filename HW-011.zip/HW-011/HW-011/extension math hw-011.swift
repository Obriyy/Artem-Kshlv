//
//  extension math hw-011.swift
//  HW-011
//
//  Created by PRPL on 08.05.2020.
//  Copyright © 2020 kosheliev. All rights reserved.
//

import Foundation

extension Mathematics {
   
   func applyKTimes(kTimes amount: Int) -> () -> Int {
      var totalValue = 0
      func multiply() -> Int {
         for _ in 0...amount {
            totalValue += amount
         }
         return totalValue
      }
      return multiply
   }
}


// TASK 1

//extension Mathematics {
//
//   enum valueType {
//      case minPerim
//      case maxPerim
//      case minArea
//      case maxArea
//   }
//
//   convenience init(description: valueType, result: ((String)->())) {
//      let description =
//
//      }
//   }
//}
