//
//  Mathematics HW-009.swift
//  HW-011
//
//  Created by PRPL on 08.05.2020.
//  Copyright © 2020 kosheliev. All rights reserved.
//

import Foundation
import Darwin

enum FigureType: Int {
   
   case unknown
   case line
   case triangle
   case square
}

class Figure {
   private (set) var points: [Point]
   private (set) var type: FigureType
   
   init(points: [Point]) {
      
      let figurePointCount = points.count
      
      switch figurePointCount {
         case 2:
            type = .line
         case 3:
            type = .triangle
         case 4:
            type = .square
         default:
            type = .unknown
      }
      
      self.points = points
   }
   
   subscript(index: Int) -> Point {
      return points[index]
   }
   
   var getPerimetrOfFigure: Double {
      switch points.count {
         case 0...2:
            return 0
         default:
            var perimetrOfFigure: Double = 0
            var j = self.points.count - 1
            
            for i in 0..<self.points.count {
               perimetrOfFigure += abs(self[i].distanceBetween(self[j]))
               j = i
            }
            return perimetrOfFigure
      }
   }
}

extension Figure {
   
   var getAreaOfFigure: Double {
      switch points.count {
         case 0...2:
            //            print("Area cant be calculated")
            return 0
         default:
            var result: Double = 0.0
            var j = self.points.count - 1
            
            for i in 0..<self.points.count {
               result += ((self[j].x + self[i].x) * (self[j].y - self[i].y))
               j = i
            }
            
            return abs(result / 2)
      }
   }
}

struct Point {
   
   private (set) var x: Double = 0.0
   private (set) var y: Double = 0.0
   
   func distanceBetween(_ point: Point) -> Double {
      return sqrt((self.x - point.x) * (self.x * point.x) + (self.y - point.y) * (self.y - point.y))
   }
   
}

final class Line: Figure {
   private (set) var startPoint = Point()
   private (set) var endPoint = Point()
   
   
   init(startPoint: Point, endPoint: Point) {
      
      super.init(points: [startPoint, endPoint])
   }
   
   func distance() -> Double {
      let result = self.startPoint.distanceBetween(endPoint)
      return result
   }
}


struct Vector {
   
   private let p1: Point
   private let p2: Point
   
   init(p1: Point, p2: Point) {
      self.p1 = p1
      self.p2 = p2
   }
   
   public func moduleOfVectors() -> Double {
      
      let module = sqrt((p2.x - p1.x) * (p2.x * p1.x) + (p2.y - p1.y) * (p2.y - p1.y))
      return module
   }
   
   public func scalar() -> Double {
      let scalars = p1.x * p2.x + p1.y * p2.y
      return scalars
   }
   
   func angleOfVectors() -> Double {
      return self.scalar() / self.moduleOfVectors()
   }
}

final class Triangle: Figure {
   
   var aAngle: Int = 0
   var bAngle: Int = 0
   var cAngle: Int = 0
   
   init?(aAngle: Int, bAngle: Int, cAngle: Int){
      let sumOfAngles = aAngle + bAngle + cAngle
      if sumOfAngles != 180 {
         return nil
      }
      super.init(points: [p1, p2])
   }
}
var p1 = Point(x: 2.3, y: 3.1)
var p2 = Point(x: 2.5, y: 3.6)

enum SquareType {
   
   case square
   case rhomb
   case rectangle
}

final class Rectangle: Figure {
   
   init(_ pointOfRect: Point...) {
      super.init(points: pointOfRect)
   }
   
   var rectangleType: SquareType {
      let aSide = self[0].distanceBetween(self[1])
      let bSide = self[1].distanceBetween(self[2])
      let cSide = self[2].distanceBetween(self[3])
      let dSide = self[3].distanceBetween(self[0])
      
      if aSide == bSide &&
         aSide == cSide &&
         aSide == dSide {
         return .square
         
      } else if
         aSide == cSide &&
            bSide == dSide &&
            aSide != dSide {
         return .rectangle
      } else {
         return .rhomb
      }
   }
}


final class Mathematics {
   private var array : [Figure] = []
   
   public var minPerim : (Double, Figure) {
      get {
         for i in 0..<array.count - 1 {
            if array[i+1].getPerimetrOfFigure < array[i].getPerimetrOfFigure {
               (array[i], array[i+1]) = (array[i+1], array[i])
            }
         }
         return (array[0].getPerimetrOfFigure, array[0])
      }
   }
   
   public var maxPerim : (Double, Figure) {
      get {
         for i in 0..<array.count - 1 {
            if array[i+1].getPerimetrOfFigure < array[i].getPerimetrOfFigure {
               (array[i], array[i+1]) = (array[i+1], array[i])
            }
         }
         return (array[array.count-1].getPerimetrOfFigure, array[array.count-1])
      }
   }
   
   public var minArea : (Double, Figure) {
      get {
         for i in 0..<array.count - 1 {
            if array[i+1].getAreaOfFigure < array[i].getAreaOfFigure {
               (array[i], array[i+1]) = (array[i+1], array[i])
            }
         }
         return (array[0].getAreaOfFigure, array[0])
      }
   }
   
   public var maxArea : (Double, Figure) {
      get {
         for i in 0..<array.count - 1 {
            if array[i+1].getAreaOfFigure < array[i].getAreaOfFigure {
               (array[i], array[i+1]) = (array[i+1], array[i])
            }
         }
         return (array[array.count-1].getAreaOfFigure, array[array.count-1])
      }
   }
   
   init(array: Figure...) {
      for figure in array {
         self.array.append(figure)
      }
      self.array.append(contentsOf: array)
   }
}

