//
//  main.swift
//  HW-011
//
//  Created by PRPL on 08.05.2020.
//  Copyright © 2020 kosheliev. All rights reserved.
//

import Foundation

var value = Mathematics()
var result = value.applyKTimes(kTimes: 3)
print(result)

var numbers = [23, 42, 15, 16, 4, 8]
var maxValue = numbers.reduce(numbers[0]) { $0 > $1 ? $0 : $1 }
print(maxValue)

var stringNumbers = ["23", "42", "15", "16", "4", "8"]
var oneString = stringNumbers.reduce("", +)
print(oneString)


func forEach(_ array: [Int], _ closure: (Int) -> ()) {
   for i in array {
      closure(i)
   }
}
forEach(numbers, { print($0 * $0) } )



// map, flatMap, compactMap, combine, reduce


let multiplyNumbers = numbers.map { $0 * $0 }
print(multiplyNumbers)

let compact = stringNumbers.compactMap(Int.init)
print(compact)

let reduce = numbers.reduce(numbers.startIndex) { $0 + $1 }
print(reduce)

let flat = oneString.compactMap { $0 }
print(flat)

