//
//  DropDown.swift
//  HW-020 - Animations
//
//  Created by PRPL on 18.06.2020.
//  Copyright © 2020 kosheliev. All rights reserved.
//

import UIKit

final class DropDownView: UIView {
   
   private var answers = [String]()
   private (set) var dropDownTableView = UITableView()
   weak var delegate: DropDownProtocol?
   
   // MARK: - Init
   
   override init(frame: CGRect) {
      super.init(frame: frame)
      
      dropDownTableView.delegate = self
      dropDownTableView.dataSource = self
      setupDropDownTableView()
   }
   
   required init?(coder: NSCoder) {
      fatalError("init(coder:) has not been implemented")
   }
   
   // MARK: - Setup views methods
   
   private func setupDropDownTableView() {
      dropDownTableView.layer.borderColor = UIColor.darkGray.cgColor
      dropDownTableView.layer.borderWidth = 2
      dropDownTableView.translatesAutoresizingMaskIntoConstraints = false
      self.addSubview(dropDownTableView)
      dropDownTableView.leftAnchor.constraint(equalTo: self.leftAnchor).isActive = true
      dropDownTableView.rightAnchor.constraint(equalTo: self.rightAnchor).isActive = true
      dropDownTableView.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
      dropDownTableView.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
   }
   
   // MARK: - DropDownView methods
   
   func appendAnswers(_ answers: [String]) {
      self.answers.append(contentsOf: answers)
   }
}

// MARK: - UITableViewDelegate

extension DropDownView: UITableViewDelegate {
   func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      let cell = UITableViewCell()
      cell.textLabel?.text = answers[indexPath.row]
      cell.backgroundColor = .white
      return cell
   }
   
   func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
      delegate?.dropDownPressed(string: answers[indexPath.row])
      dropDownTableView.deselectRow(at: indexPath, animated: true)
   }
}

// MARK: - UITableViewDataSource

extension DropDownView: UITableViewDataSource {
   func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      return answers.count
   }
}
