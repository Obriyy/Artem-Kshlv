//
//  DropDownButton.swift
//  HW-020 - Animations
//
//  Created by PRPL on 19.06.2020.
//  Copyright © 2020 kosheliev. All rights reserved.
//

import UIKit

protocol DropDownProtocol: class {
   func dropDownPressed(string: String)
}

final class DropDownButton: UIButton, DropDownProtocol {
   
   private var dropView = DropDownView()
   private var height = NSLayoutConstraint()
   private var isOpen = false
   weak var delegate: RotateArrow?
   
   // MARK: - Init
   
   override init(frame: CGRect) {
      super.init(frame: frame)
   
      self.layer.borderColor = UIColor.darkGray.cgColor
      self.layer.borderWidth = 2
      
      dropView = DropDownView.init(frame: CGRect.init(x: 0, y: 0, width: 0, height: 0))
      dropView.delegate = self
      dropView.translatesAutoresizingMaskIntoConstraints = false
   }
   
   required init?(coder: NSCoder) {
      fatalError("init(coder:) has not been implemented")
   }
   
   // MARK: - Lifecycle
   
   override func didMoveToSuperview() {
      self.superview?.addSubview(dropView)
      self.superview?.bringSubviewToFront(dropView)
      dropView.topAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
      dropView.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
      dropView.widthAnchor.constraint(equalTo: self.widthAnchor).isActive = true
      height = dropView.heightAnchor.constraint(equalToConstant: 0)
   }
   
   // MARK: - Touches methods
   
   override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
      if isOpen == false {
         isOpen = true
         NSLayoutConstraint.deactivate([self.height])
         if dropView.dropDownTableView.contentSize.height > 150 {
            height.constant = 150
         } else {
            height.constant = dropView.dropDownTableView.contentSize.height
         }
         NSLayoutConstraint.activate([self.height])
         
         UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: .curveEaseInOut, animations: {
            self.dropView.layoutIfNeeded()
            self.dropView.center.y += self.dropView.frame.height / 2
         }, completion: nil)
      } else {
         isOpen = false
         NSLayoutConstraint.deactivate([self.height])
         height.constant = 0
         NSLayoutConstraint.activate([self.height])
         closeAnimation()
      }
   }
   
   // MARK: - Animations
   
   private func closeAnimation() {
      UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: .curveEaseInOut, animations: {
         self.dropView.center.y -= self.dropView.frame.height / 2
         self.dropView.layoutIfNeeded()
      }, completion: nil)
   }
   
   //MARK: - DropDownButton methods
   
   private func dismissDropDown() {
      isOpen = false
      NSLayoutConstraint.deactivate([self.height])
      self.height.constant = 0
      NSLayoutConstraint.activate([self.height])
      closeAnimation()
   }
   
   func fill(answers: [String]) {
      dropView.appendAnswers(answers)
   }
   
   //MARK: - DropDownProtocol methods
   
   func dropDownPressed(string: String) {
      self.setTitle(string, for: .normal)
      delegate?.changeArrow()
      dismissDropDown()
   }
}
