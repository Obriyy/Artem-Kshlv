//
//  ComboBox.swift
//  HW-020 - Animations
//
//  Created by PRPL on 17.06.2020.
//  Copyright © 2020 kosheliev. All rights reserved.
//

import UIKit

protocol RotateArrow: class {
   func changeArrow()
}

final class ComboBoxViewController: UIViewController, RotateArrow {
   
   private var chooseButton = DropDownButton()
   private let arrowView = UIImageView(image: UIImage(named: "arrow"))
   private var arrowState: Bool = false
   
   // MARK: - Lifecycle
   
   override func viewDidLoad() {
      super.viewDidLoad()
      
      setupButton()
   }
   
   // MARK: - Actions methods
   
   
   @IBAction func resetButton(_ sender: UIBarButtonItem) {
      chooseButton.setTitle("What is day today?", for: .normal)
   }
   
   @objc internal func changeArrow() {
      if arrowState == false {
         arrowState = true
         UIView.animate(withDuration: 0.5) {
            self.arrowView.layer.transform = CATransform3DMakeRotation(.pi, 0, 0, 1)
         }
      } else {
         arrowState = false
         UIView.animate(withDuration: 0.5) {
            self.arrowView.layer.transform = CATransform3DMakeRotation(-2 * .pi, 0, 0, 1)
         }
      }
   }
   
   // MARK: - Setup views
   
   private func setupButton() {
      chooseButton = DropDownButton.init(frame: CGRect(x: 0, y: 0, width: 0, height: 0))
      chooseButton.fill(answers: ["answer 1", "answer 2", "answer 3", "answer 4", "answer 5"])
      chooseButton.setTitle("What is day today", for: .normal)
      setupArrow()
      chooseButton.setTitleColor(.black, for: .normal)
      chooseButton.contentEdgeInsets = UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 20)
      chooseButton.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(changeArrow)))
      chooseButton.delegate = self
      chooseButton.translatesAutoresizingMaskIntoConstraints = false
      self.view.addSubview(chooseButton)
      chooseButton.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
      chooseButton.centerYAnchor.constraint(equalTo: self.view.centerYAnchor).isActive = true
      chooseButton.widthAnchor.constraint(equalToConstant: 275).isActive = true
      chooseButton.heightAnchor.constraint(equalToConstant: 40).isActive = true
   }
   
   private func setupArrow() {
      arrowView.center = CGPoint(x: 260, y: 20)
      chooseButton.addSubview(arrowView)
   }
   
}
