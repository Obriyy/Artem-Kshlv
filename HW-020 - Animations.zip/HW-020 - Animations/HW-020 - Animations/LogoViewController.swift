//
//  ViewController.swift
//  HW-020 - Animations
//
//  Created by PRPL on 13.06.2020.
//  Copyright © 2020 kosheliev. All rights reserved.
//

import UIKit

private struct Image {
   var layer: CALayer
   var position: CGPoint
   var state: Bool
   
}

final class LogoViewController: UIViewController {

   private var bing = Image(layer: CALayer(), position: CGPoint(x: 0, y: 0), state: false)
   private var google = Image(layer: CALayer(), position: CGPoint(x: 0, y: 0), state: false)
   private var youtube = Image(layer: CALayer(), position: CGPoint(x: 0, y: 0), state: false)
   private var apple = Image(layer: CALayer(), position: CGPoint(x: 0, y: 0), state: false)
   private var microsoft = Image(layer: CALayer(), position: CGPoint(x: 0, y: 0), state: false)
   
   private var imagesArray = [Image]()
   private var imagesNames = ["bing", "google", "youtube", "apple", "microsoft"]
   private var imagesOnScreen = [String]()
   private var stateCount = 0
   private var imageCount = 0
   
   private let rotation = CAKeyframeAnimation()
   private let scale = CAKeyframeAnimation()
   private let opacity = CAKeyframeAnimation()
   
   
   // MARK: - LifeCycle
   
   override func viewDidLoad() {
      super.viewDidLoad()
      
      imagesArray.append(contentsOf: [apple, bing, google, microsoft, youtube])
      createShowAnimation()
   }
   
   // MARK: - Buttons actions
   
   @IBAction func resetButton(_ sender: UIBarButtonItem) {
      imageCount = 0
      stateCount = 0
      imagesOnScreen.removeAll()
      
      imagesArray.forEach { (image) in
         image.layer.removeFromSuperlayer()
      }
      
      for (index, _) in imagesArray.enumerated() {
         imagesArray[index].layer = CALayer()
         imagesArray[index].state = false
         imagesArray[index].position = CGPoint(x: 0, y: 0)
      }
      
   }
   
   override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
      super.touchesBegan(touches, with: event)
      let touch = touches.first
      guard let location = touch?.location(in: self.view) else {
         return
      }
      guard let hitLayer = self.view.layer.hitTest(self.view.convert(location, from: nil)) else {
         return
      }
   
      if imagesOnScreen.count != 5 {
         imagesArray[imageCount].position = location
         appendImage(location, layer: imagesArray[imageCount].layer)
         imageCount += 1
      }
      moveForTouch(hitLayer)

   }
   

   // MARK: - Animations
   
   private func createShowAnimation() {
      rotation.keyPath = "transform.rotation"
      rotation.values = [0, 2 * CGFloat.pi]
      rotation.isRemovedOnCompletion = false
      rotation.duration = 0.5
   
      scale.keyPath = "transform.scale"
      scale.values = [2, 1]
      scale.isRemovedOnCompletion = false
      scale.duration = 0.5
      
      opacity.keyPath = "opacity"
      opacity.values = [0, 1]
      opacity.isRemovedOnCompletion = false
      opacity.duration = 0.5
      
   }
   
   // MARK: - Image methods
   
   private func appendImage(_ location: CGPoint, layer: CALayer) {
      layer.name = "\(imageCount)"
      layer.contents = UIImage(named: findImage())?.cgImage
      layer.frame = CGRect(x: location.x - 50, y: location.y - 75, width: 100, height: 150)
      layer.bounds = CGRect(x: 0, y: 0, width: 100, height: 150)
      layer.add(rotation, forKey: nil)
      layer.add(scale, forKey: nil)
      layer.add(opacity, forKey: nil)
      view.layer.addSublayer(layer)
   }
   
   private func findImage() -> String {
      for name in imagesNames {
         if !imagesOnScreen.contains(name) {
            imagesOnScreen.append(name)
            return name
         }
      }
      return ""
   }

   
   private func moveForTouch(_ hitLayer: CALayer) {
      guard let name = hitLayer.name else {
         return
      }
      guard let index = Int(name) else {
         return
      }
      
      if imagesOnScreen.count == 5 && hitLayer != view.layer {
         if imagesArray[index].state == false {
            if stateCount == 1 {
               return
            }
            imagesArray[index].state = true
            hitLayer.bringToFront()
            CATransaction.begin()
            CATransaction.setAnimationDuration(1)
            hitLayer.position = view.center
            hitLayer.transform = CATransform3DMakeScale(2, 2, 1)
            CATransaction.commit()
            stateCount += 1
         } else {
            imagesArray[index].state = false
            stateCount -= 1
            CATransaction.begin()
            CATransaction.setAnimationDuration(1)
            hitLayer.position = imagesArray[index].position
            hitLayer.transform = CATransform3DMakeScale(1, 1, 1)
            CATransaction.commit()
            hitLayer.sendToBack()
         }
      }
   }
}
extension CALayer {
   func bringToFront() {
      guard let sLayer = superlayer else {
         return
      }
      removeFromSuperlayer()
      sLayer.insertSublayer(self, at: UInt32(sLayer.sublayers?.count ?? 0))
   }
   
   func sendToBack() {
      guard let sLayer = superlayer else {
         return
      }
      removeFromSuperlayer()
      sLayer.insertSublayer(self, at: 0)
   }
}
