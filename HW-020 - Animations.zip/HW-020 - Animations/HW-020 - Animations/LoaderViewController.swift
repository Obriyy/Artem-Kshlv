//
//  LoaderViewController.swift
//  HW-020 - Animations
//
//  Created by PRPL on 17.06.2020.
//  Copyright © 2020 kosheliev. All rights reserved.
//

import UIKit

final class LoaderViewController: UIViewController {
   
   private let circularPath = UIBezierPath(arcCenter: .zero, radius: 100, startAngle: 0, endAngle: 2 * .pi, clockwise: true)
   private let loaderLayer = CAShapeLayer()
   private let trackLayer = CAShapeLayer()
   private var timer = Timer()
   private var isRunning: Bool = false
   private var counter: CGFloat = 0 {
      didSet {
         if counter == 1000.0 {
            timer.invalidate()
            isRunning = false
         }
      }
   }
   
   private var procentageLabel: UILabel = {
      let label = UILabel()
      label.frame = CGRect(x: 0, y: 0, width: 120, height: 100)
      label.text = "Start"
      label.textAlignment = .center
      label.textColor = .black
      label.font = UIFont.systemFont(ofSize: 32)
      return label
   }()
   
   override func viewDidLoad() {
      super.viewDidLoad()
      
      setupTrackLayer()
      setupLoaderLayer()
      
      view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(handleTap)))
      
      view.addSubview(procentageLabel)
      procentageLabel.center = view.center
   }
   
   // MARK: - Button actions
   
   @IBAction func resetButton(_ sender: UIBarButtonItem) {
      timer.invalidate()
      loaderLayer.strokeEnd = 0
      isRunning = false
      counter = 0
      procentageLabel.text = "Start"
      trackLayer.isHidden = true
   }
   
   @objc private func handleTap() {
      if isRunning == false {
         trackLayer.isHidden = false
         counter = 0
         timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(loadPrecessed), userInfo: nil, repeats: true)
      } else {
         return
      }
   }
   
   // MARK: - Setup loader view
   
   private func setupTrackLayer() {
      trackLayer.path = circularPath.cgPath
      trackLayer.strokeColor = UIColor.lightGray.cgColor
      trackLayer.lineWidth = 10
      trackLayer.fillColor = UIColor.clear.cgColor
      trackLayer.lineCap = CAShapeLayerLineCap.round
      trackLayer.position = view.center
      trackLayer.isHidden = true
      view.layer.addSublayer(trackLayer)
   }
   
   private func setupLoaderLayer() {
      loaderLayer.path = circularPath.cgPath
      loaderLayer.strokeColor = UIColor.red.cgColor
      loaderLayer.lineWidth = 10
      loaderLayer.fillColor = UIColor.clear.cgColor
      loaderLayer.lineCap = CAShapeLayerLineCap.round
      loaderLayer.strokeEnd = 0
      loaderLayer.position = view.center
      loaderLayer.transform = CATransform3DMakeRotation(-.pi / 2, 0, 0, 1)
      view.layer.addSublayer(loaderLayer)
   }
   
   // MARK: - Timer actions
   
   @objc private func loadPrecessed() {
      self.procentageLabel.text = "\(self.counter / 10)%"
      self.loaderLayer.strokeEnd = CGFloat(self.counter / 1000)
      UIView.animate(withDuration: 0.1, animations: {
         self.procentageLabel.transform = CGAffineTransform(scaleX: 3, y: 3)
         self.procentageLabel.transform = CGAffineTransform(scaleX: 1, y: 1)
      })
      counter += 1
   }
   
}
