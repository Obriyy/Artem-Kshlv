//
//  ViewController.swift
//  HW-014
//
//  Created by PRPL on 20.05.2020.
//  Copyright © 2020 kosheliev. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

   override func viewDidLoad() {
      super.viewDidLoad()
      // Do any additional setup after loading the view.
   }


}

