//
//  AppDelegate.swift
//  HW-014
//
//  Created by PRPL on 20.05.2020.
//  Copyright © 2020 kosheliev. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

   var window: UIWindow?

   
   // MARK: - LifeCycle

   func application(_ application: UIApplication, willFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
      print("AppDelegate - willFinishLaunchingWithOptions")
      return true
   }

   func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
      print("AppDelegate - didFinishLaunchingWithOptions")
      return true
  }
   
   // will activates after calling
   func applicationWillResignActive(_ application: UIApplication) {
      print("AppDelegate - applicationWillResignActive")
   }
   
   //falled in background
   func applicationDidEnterBackground(_ application: UIApplication) {
      print("AppDelegate - applicationDidEnterBackground")
   }
   
   //will activates in foreground after calling
   func applicationWillEnterForeground(_ application: UIApplication) {
      print("AppDelegate - applicationWillEnterForeground")
   }
   
   //becomes active
   func applicationDidBecomeActive(_ application: UIApplication) {
      print("AppDelegate - applicationDidBecomeActive")
   }
   
   //closed after opening
   func applicationWillTerminate(_ application: UIApplication) {
      print("AppDelegate - applicationWillTerminate")
   }
   
   //receive by "Simulate memory warning"(Debug menu) in Simulator app
   func applicationDidReceiveMemoryWarning(_ application: UIApplication) {
      print("AppDelegate - applicationDidReceiveMemoryWarning")
   }
   
   // не можу зрозуміти, як викликати цей метод
   func applicationSignificantTimeChange(_ application: UIApplication) {
      print("AppDelegate - applicationSignificantTimeChange")
   }
   
   //receive when app needs Health authorization(device apps or watch apps)
   func applicationShouldRequestHealthAuthorization(_ application: UIApplication) {
      print("AppDelegate - applicationShouldRequestHealthAuthorization")
   }
   
   //lock device
   func applicationProtectedDataWillBecomeUnavailable(_ application: UIApplication) {
      print("AppDelegate - applicationProtectedDataWillBecomeUnavailable")
   }
   
   // unlock device
   func applicationProtectedDataDidBecomeAvailable(_ application: UIApplication) {
      print("AppDelegate - applicationProtectedDataDidBecomeAvailable")
   }
   
}


