//
//  Clock.swift
//  HW-019 - Alarm Clock
//
//  Created by PRPL on 08.06.2020.
//  Copyright © 2020 kosheliev. All rights reserved.
//

import Foundation

final class Clock {
   
   var currentTime: Date {
      return Date()
   }
   
}
