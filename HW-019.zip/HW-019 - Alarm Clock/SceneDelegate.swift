//
//  SceneDelegate.swift
//  HW-019 - Alarm Clock
//
//  Created by PRPL on 05.06.2020.
//  Copyright © 2020 kosheliev. All rights reserved.
//

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

   var window: UIWindow?

}

