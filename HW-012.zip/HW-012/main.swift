//
//  main.swift
//  HW-012
//
//  Created by PRPL on 13.05.2020.
//  Copyright © 2020 kosheliev. All rights reserved.
//

import Foundation

protocol Storable {
   associatedtype T
   
   func store(object: T)
}

class Queue<T: Storable>: ExpressibleByArrayLiteral {
   
   
   // MARK: - property
   
   private (set) var array = [T]()
   
   // MARK: - subscripts
   
   subscript(index: Int) -> T {
         array[index]
   }
   
   // MARK: - funtions
   
   func push(_ object: T) {
      array.append(object)
   }
   
   func pop() throws -> T? {
      if array.isEmpty {
         throw ErrorOfArray.stackIsEmpty
      }
         return array.removeFirst()
   }
   
   var count: Int {
      array.count
   }
   
   // MARK: - inits
    
   required init(arrayLiteral elements: T...) {
      array = elements
   }
   
   enum ErrorOfArray: Error {
      
      case unknown
      case stackIsEmpty
   
   }
}


struct SomeObject: Storable {
   typealias T = String
   
   func store(object: String) {
      //
   }
}

let queue: Queue = [
   SomeObject(),
   SomeObject(),
   SomeObject(),
   SomeObject()
]

let object = try? queue.pop()
let object2 = try? queue.push(SomeObject())
try? queue.count

