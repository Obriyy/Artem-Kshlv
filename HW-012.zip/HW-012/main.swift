//
//  main.swift
//  HW-012
//
//  Created by PRPL on 13.05.2020.
//  Copyright © 2020 kosheliev. All rights reserved.
//

import Foundation

protocol Storable {
   associatedtype SomeType
   
   func doStuff()
}

class Queue<V>: Storable {
   
   typealias SomeType = V
   
   // MARK:  property
   
   var array = [V]()
   var arrayForReturn = [V]()
   
   // MARK:  subscripts
   
   subscript(index: Int) -> V {
      array[index]
   }
   
   // MARK:  funtions
   
   func doStuff() {
      //do some stuff
   }
   
   func appendItem(_ item: V) {
      array.append(item)
      arrayForReturn.append(item)
   }
   
   func removeAll() {
      array.removeAll()
   }
   
   func returnAll() {
      array.append(contentsOf: arrayForReturn)
   }
   
   func remove() {
      array.removeLast()
      
   }
   
}


var ete = Queue<String>()
ete.appendItem("ss")
ete.appendItem("ww")
ete.appendItem("223")

print(ete.returnAll())
print(ete.array)
print(ete.arrayForReturn)

